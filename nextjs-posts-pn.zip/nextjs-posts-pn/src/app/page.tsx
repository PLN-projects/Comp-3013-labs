export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between main-area">
      <h1>Next JS Post Interface</h1>
    </main>
  )
}
